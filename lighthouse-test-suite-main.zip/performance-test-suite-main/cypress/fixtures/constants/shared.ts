export const shared = {
  users: {
    authoringUser: {
      //// User for login into authoring app
      username: 'cha\\SptCmsTestEditor@cha.rbxd.ds',
    },
    subscriberUser: {
      //// User for login into subscriber app
      username: 'chubtestuser@icis.com',
    }
  },
  enviroment: {
    subscriber: {
      systest:'https://subscriber.systest.genesis.cha.rbxd.ds/mfe/image?id=',
      staging: 'https://subscriber.staging.genesis.cha.rbxd.ds/mfe/image?id=',
    }
  },
  
};
