/// <reference types="cypress" />
import { shared } from '../../../fixtures/constants/shared';

export class ImageCardPage {
  exportButton = 'button[id="export"]';
  clickImageCard = 'div[aria-label="Choose a Component Modal"]>div:nth-of-type(2)>div';
  addImageOnImageCard = 'div[data-testid^="image_capability"]>div:nth-of-type(1)>button';
  AddtoPageButton = 'div[class="validationMessageSection"]+button';
  subscriberUsername ='input[id="username-input"]';
  subscriberPassword = 'input[id="password-input"]';
  subcriberLoginButton ='button[id="login-button"]';
  subscriberImage = 'div[data-testid="image__container__box"]>div>img';

public clickOnAddImage(){
  cy.get(this.addImageOnImageCard,{ timeout: 5000 }).should('contain', "Add image");
  cy.get('div',{ timeout: 5000 }).contains('Add image').click();
}

public selectAndUploadImage(){
  cy.get('div').contains('Browse your computer').click();
  cy.get('input[type=file]').selectFile('cypress/fixtures/test_images/icis.png',{ force: true })
}

public clickAddToPageButton() {
  return cy.get(this.AddtoPageButton).click();
}

public LoginIntoSubscriberView(){
  cy.get(this.subscriberUsername).type(shared.users.subscriberUser.username);
  cy.get(this.subscriberPassword).type(Cypress.env('password'));
  cy.get(this.subcriberLoginButton).click();
  cy.wait(12000);
}
public validateImageinSubscriberView(){
  cy.get(this.subscriberImage,{ timeout: 2000 }).should('have.attr','data-testid','image__element');
}

}
