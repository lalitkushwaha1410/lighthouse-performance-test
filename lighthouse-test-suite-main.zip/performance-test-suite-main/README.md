# Cypress MFE Performance Test Suite

This README file provides an overview of the MFE Performance test suite for the Image Capability. The suite includes performance tests for Authoring and Subscriber for the Image Capability , as well as report generation.And it also includes the instructions on how to run it using GitLab pipelines.

## MFE Performance Test Suite Overview

The Image Capability Cypress performance test suite is designed to verify the performance for uploading and displaying the image of the Image Capability. Also html report will be generated under the report folder of the project

## Running the Test Suite

To run the k6 performance load test suite using GitLab pipelines, you can utilize variable: `ENV`and `NOTIFY` .

### Environment Variable (`ENV`) 

The `ENV` variable specifies the target environment for the tests. It can take the following values:

- `systest`: Tests against the system test environment.
- `staging`: Tests against the staging environment.
- `performance`(default): Tests focused on performance testing.
- `integration`: Tests for integration scenarios.

### Environment Variable (`NOTIFY`) 

The `NOTIFY` variable specifies whether you need the Teams notification to be generated. It can take the following values:

- `true`:  Teams notification will be generated based on performance test suite result.
- `false`(default): Teams notification will not be generated.

You can choose the desired environment by setting the `ENV` variable and notification by setting the `NOTIFY` variable accordingly in your GitLab pipeline configuration.

### Running the Pipeline

To run the Cypress performance test suite with the default configuration (performance environment), you can use the following command in your GitLab pipeline configuration:

```yaml
test:
  script:
    - yarn install
    - yarn add puppeteer-core
    - yarn add -g lighthouse && yarn add --dev @lhci/cli@0.12.0
    - yarn cypress run --browser chrome --env ENV=$ENV
```

Modify the default `ENV` value in the above command as per your requirements.

### Notification on Teams
To generate notification on teams with test suite result do the $TEAMS_WEBHOOK_URL variable setting on Gitlab. You can modify the data to be displayed as a part of Team Notification through Gitlab yaml file.

## Additional Configuration

You can further customize the Cypress performance test suite by modifying the test scripts or adding additional plugins as required by your project.

## Feedback and Issues

If you encounter any issues or have suggestions for improving the Cypress test suite, please feel free to submit them through the [Mercury](https://teams.microsoft.com/l/channel/19%3a13aa0dd5073847f28cfa18872932f82e%40thread.tacv2/General?groupId=1b1d3792-4134-4b44-8a2c-a4ce6e15e422&tenantId=9274ee3f-9425-4109-a27f-9fb15c10675d) channels. Your feedback is valuable for maintaining and enhancing the test suite's effectiveness.

Happy testing!
